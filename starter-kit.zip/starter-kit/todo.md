# To-do

Open work only. Finished items move to done.md. Tiers: p1 this week (7 at most), p2 this month, p3 someday.

## P1 (this week)

- [ ] Fill in CLAUDE.md from my about-me file (added on setup day) <!--p1-->
- [ ] Record five voice memos this week, little ones count (added on setup day) <!--p1-->

## Open

## Lists
