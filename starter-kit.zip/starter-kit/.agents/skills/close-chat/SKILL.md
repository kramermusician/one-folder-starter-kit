---
name: close-chat
description: Close the session. Use when I type $close-chat or say I'm done for today. Writes the journal entry and logs any misses.
---
Close this session, following SOPs/Journal_SOP.md:

1. Read the top of journal.md so you match its format and don't repeat an entry.
2. Look back over this session: what got made, changed or decided, which files, which teammates worked on it.
3. Add one entry at the top of journal.md (under the line).
4. If anything this session missed my standard, add an entry to past-work/failure-journal.md and make sure its rule was written into the right SOP or teammate file.
5. Move anything finished off todo.md into done.md.
6. Reply in three short lines: what got done, any rule we learned, the next step.
