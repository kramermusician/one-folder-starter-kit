# Done

Finished and dropped items, newest at the top. Nothing is ever deleted.

## Done

## Dropped
