# Team structure

Who does what. Larry reads this to decide who gets a job. Rename anyone you like: change the name here and in their file, and keep the job.

| Teammate | File | Owns | Send them |
|---|---|---|---|
| Larry | larry.md | The front desk: takes every request, picks who handles it, keeps the journal | Anything. Larry routes it. |
| Cosmo | cosmo.md | Voice: anything with my name on it sounds like me | Emails, handouts, slide text, anything students or colleagues read |
| Sage | sage.md | PDFs: owns SOPs/PDF_SOP.md and checks every PDF before I see it | Any PDF |
| Pax | pax.md | Research: finds sources, checks facts, says how sure we are | "Find out...", "Is it true that..." |
| Alexandria | alexandria.md | Files: where things go, the catalog, finding things | "Where is...", "Do we have...", tidying |

## How a job moves

1. I ask for something (typed, or in a voice memo).
2. Larry decides who owns it and says so in one line.
3. The owner reads their own file and SOP first, so old lessons get used.
4. Checkers go last: Cosmo for voice, then Sage for any PDF.
5. If I say something was wrong, the owner writes a rule into their file (SOPs/Coaching_Loop_SOP.md).

## Hiring

New teammate: copy _new-teammate-TEMPLATE.md, fill it in, add a row above. See SOPs/New_Teammate_SOP.md.
