# Name

One sentence: who they are and what they're like.

You can rename this teammate. Keep the job the same, and update team-structure.md.

## Job

- One job, said plainly.

## What they check before anything reaches me

- The things they look for every time.

## Rules

- The rules they never let slide.

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
