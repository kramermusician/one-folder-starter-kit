#!/bin/bash
# Step 5: start the memo watcher. It keeps running after you close this window, and after a restart.
# Safe to run twice: running it again restarts the watcher (do that after you move your folder).
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
OF="$HOME/.onefolder"
PY="$OF/venv/bin/python"
LABEL="${ONEFOLDER_LABEL:-com.onefolder.watcher}"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

echo ""
echo "Starting your memo watcher ..."

[ -x "$PY" ] || { echo "CHECK: Whisper isn't installed yet. Double-click 03-install-whisper.command first."; exit 1; }
CLAUDE=""
for c in "$HOME/.local/bin/claude" /opt/homebrew/bin/claude /usr/local/bin/claude; do [ -x "$c" ] && CLAUDE="$c" && break; done
if [ -z "$CLAUDE" ]; then
  CODEX=""
  for c in "$HOME/.local/bin/codex" "$HOME/.npm-global/bin/codex" /opt/homebrew/bin/codex /usr/local/bin/codex $(ls -d "$HOME"/.nvm/versions/node/*/bin/codex 2>/dev/null); do [ -x "$c" ] && CODEX="$c" && break; done
  if [ -n "$CODEX" ]; then echo "  Using Codex to route memos."; else echo "  NOTE Neither Claude Code nor Codex is installed yet, so memos will be transcribed but not routed. Run 02 first."; fi
fi

# The watcher's own code lives outside Dropbox, so it always starts, even if Dropbox is busy.
mkdir -p "$OF/bin" "$HOME/Library/LaunchAgents" inbox/voice inbox/transcripts inbox/processed
cp tools/watcher.py tools/transcribe.py tools/route-prompt.md "$OF/bin/"

cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>$PY</string>
    <string>$OF/bin/watcher.py</string>
    <string>$HERE</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>$OF/venv/bin:$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
    <key>HOME</key><string>$HOME</string>
    <key>PYTHONUNBUFFERED</key><string>1</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>30</integer>
  <key>StandardOutPath</key><string>$OF/watcher-launchd.log</string>
  <key>StandardErrorPath</key><string>$OF/watcher-launchd.log</string>
</dict>
</plist>
PLISTEOF

launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null
sleep 1
launchctl bootstrap "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl load -w "$PLIST" 2>/dev/null

# Wait for the watcher to say hello in its log
started=""
for i in $(seq 1 20); do
  sleep 1
  if launchctl print "gui/$(id -u)/$LABEL" 2>/dev/null | grep -q "state = running"; then
    if tail -n 5 inbox/watcher.log 2>/dev/null | grep -q "watcher running"; then started=1; break; fi
  fi
done

echo ""
if [ -n "$started" ]; then
  echo "watcher running"
  echo ""
  echo "CHECK: your system is listening to inbox/voice/. You can close this window."
  echo "To pause it, make an empty file named watcher-off inside inbox/."
else
  echo "CHECK: the watcher didn't start. Last lines of its log:"
  tail -n 8 "$OF/watcher-launchd.log" 2>/dev/null
  echo "Most common fix: in Finder, right-click this folder, choose 'Make available offline', then run this again."
fi
echo ""
