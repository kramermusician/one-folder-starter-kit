#!/bin/bash
# Step 2: install Claude Code (Anthropic's official installer). Safe to run twice; it updates in place.
cd "$(dirname "$0")" || exit 1

echo ""
echo "Installing Claude Code. This takes a minute or two."
echo ""

if [ -x "$HOME/.local/bin/claude" ] || command -v claude >/dev/null 2>&1; then
  echo "Claude Code is already here. Checking for updates instead."
fi

curl -fsSL https://claude.ai/install.sh | bash

# Make sure new Terminal windows can find it
if ! grep -q '.local/bin' "$HOME/.zshrc" 2>/dev/null; then
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
fi
export PATH="$HOME/.local/bin:$PATH"

echo ""
if command -v claude >/dev/null 2>&1; then
  echo "CHECK: Claude Code $(claude --version 2>/dev/null) is installed."
  echo ""
  echo "Next: double-click open-claude.command."
  echo "The first time, it opens a browser page so you can log in with the Claude account you pay for."
  echo "Pick the login that uses your Claude subscription (Pro or Max)."
else
  echo "CHECK: something went wrong. Take a photo of this window and show Kramer."
fi
echo ""
