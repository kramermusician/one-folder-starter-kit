# Connectors SOP (Gmail and Google Calendar)

Owner: Larry. This is a session 2 topic. Read it before connecting anything.

## What connecting means

Claude can be given access to your Gmail and Google Calendar (in Claude's settings, under Connectors). Then it can read mail, write drafts, and add events for you.

## The rules

- Gmail: drafts only. Claude writes a draft and tells you it's there. It never sends. You read it and press Send yourself.
- Calendar: Claude adds or changes an event only when you ask for that event. It never invites other people without your yes.
- Student emails get Cosmo's voice check before you see the draft.
- Never paste student grades or private notes into an email draft.
- If something feels off, disconnect it in Claude's settings. Nothing in this folder breaks.

## Good first uses

- "Draft a reply to the email from ___ saying ___."
- "Add my office hours to my calendar: Tuesdays 2 to 3 until December 15."
- "Look at my calendar for next week and tell me which classes still need materials."

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
