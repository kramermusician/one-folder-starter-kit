# Coaching loop SOP

Owner: Larry. This is how the system gets better every week. Feed it, then coach it.

## The loop

1. Mistake: something comes out wrong (too formal, wrong file, a table split across pages).
2. Owner: Larry names the teammate who owns that kind of thing (team/team-structure.md).
3. Rule: the owner writes one dated rule at the end of their file, or the SOP they own, under "Rules learned":
   - (My rule, 2026-11-17) Handouts for beginners use one table at most.
4. Better output: next time, the owner reads their file before working, and the rule is used.

## What makes a good rule

- One line, specific, testable. "Use shorter sentences" is weak. "Student handouts: no sentence over 15 words" is strong.
- Dated, so you can see how the system grew.
- In the owner's file, not scattered. One home per rule.

## Say it like this

"That was wrong because ___. Write a rule into the right teammate's file so it never happens again, and show me the rule."

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
