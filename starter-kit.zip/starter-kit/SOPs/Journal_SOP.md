# Journal SOP

Owner: Larry. journal.md is the work log, so each session knows what happened last time.

## When

- When I say "journal it".
- At the end of a session where something real got built or decided.

## Format (newest at the top, under the line)

```
## YYYY-MM-DD: Short title

What we did: two or three sentences.
Files: the main files made or changed, as paths.
Who worked on it: the teammates involved.
Next: the next step, if any.
```

Keep each entry short. When the file gets long (over about 300 lines), move older entries to `journal-archive.md`.

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
