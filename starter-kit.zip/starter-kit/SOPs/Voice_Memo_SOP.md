# Voice memo SOP

Owner: Larry. How a memo becomes notes, to-dos and people pages.

## The path

1. I press the record button on my phone (the Shortcut). The recording saves into Dropbox, in `inbox/voice/`.
2. The watcher sees it, waits until it has fully arrived, and Whisper turns it into text on this Mac.
3. The text is saved in `inbox/transcripts/`. The audio moves to `inbox/processed/`.
4. Claude routes it with `tools/route-prompt.md`: to-dos into `todo.md`, people into `people/`, ideas into `projects/` or `topics/`.
5. One line goes into `activity-log.md`.

## How to talk to it

- Say what kind of thing it is: "Reminder...", "Idea for my harmony class...", "I met...".
- Use full names for people the first time.
- Requests to make something ("make me a worksheet on chord tones for Thursday") become a to-do and a note in `output/_New/`. The watcher never builds things by itself. Open Claude and say "build the requests in output/_New/".
- English or Spanish, either one. It writes notes in the language you spoke. Stick to one language per memo: Whisper picks one language for each half minute, so a memo that switches mid-sentence can lose the other half.

## When something goes wrong

- Nothing happened: is the watcher running? Run `04-start-watcher.command` again. Check `inbox/watcher.log`.
- Pause it: make an empty file named `watcher-off` inside `inbox/`. Delete it to resume.
- A name came out wrong: fix the page, then add the right spelling to that person's `aliases` line so next time it matches.
- It filed something in the wrong place: tell Claude, and have Larry write a rule into `tools/route-prompt.md` (Coaching_Loop_SOP.md).

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
