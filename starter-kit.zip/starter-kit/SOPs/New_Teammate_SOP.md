# New teammate SOP

Owner: Larry. How to add someone to the team.

## When to hire

When you keep saying "make sure X" about the same kind of work, X needs an owner. Examples: someone for quizzes and rubrics, someone for Spanish grammar, someone for your calendar, someone for music theory charts.

## How

1. Copy `team/_new-teammate-TEMPLATE.md` to `team/<name>.md`.
2. Fill in: a name you enjoy saying, one job, what they check, and two or three rules.
3. Add a row to `team/team-structure.md`.
4. Give them an SOP if their job has steps (copy the shape of the ones in SOPs/).
5. Try them out: "Use <name> to ..." and see if the result is better than before.

Or just ask Claude: "Hire a teammate who owns ___. Write their file and add them to the team."

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
