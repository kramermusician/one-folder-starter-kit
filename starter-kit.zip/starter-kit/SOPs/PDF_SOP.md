# PDF SOP

Owner: Sage. Read this before building any PDF. Sage checks every PDF against it before I see it.

The starting point for every PDF is `tools/pdf_template.py`. Copy it, change the content, keep the rules. Run it with:

```
~/.onefolder/venv/bin/python tools/pdf_template.py
```

## 1. Page setup

- US Letter, 0.75 inch margins on all sides.
- Fonts: title 16 pt, headings 11 to 12 pt, body 10 to 11 pt, footer 8 pt italic.
- One accent color, used on purpose. Print-friendly: light backgrounds, dark text.

## 2. Footer (every page)

- Centered, 8 pt italic, at the bottom: my name and school, set once in `tools/pdf_template.py` (`FOOTER`).
- No teammate names anywhere in a PDF. Not Larry, not Sage, nobody. Only my name.

## 3. Tables (the rules that save the most pain)

- Column widths come from the content, not from guesses. The template's `fit_columns()` measures the text and shares out the page width.
- Every cell is a Paragraph, so long text wraps. Never put a plain string over 30 characters in a cell.
- No column narrower than: 0.8 in for symbols, 1.2 in for single words, 1.8 in for phrases, 2.5 in for sentences.
- Two or three columns is best. Four is the most for a handout.
- The header row repeats if a table runs onto a second page (`repeatRows=1`).
- Check before you build: the template's `check_table()` warns when a word is too long for its column. Fix the warning, don't ignore it.

## 4. Page breaks (no awkward splits)

- A heading always stays with what follows it. Wrap a heading and its first block in `KeepTogether`.
- A short table (under about a third of a page) never splits. Wrap it in `KeepTogether`.
- No forced page break while the page above still has room. A half-empty page means the layout is wrong; fix the cause.
- No heading alone at the bottom of a page, no single line alone at the top of one.
- Never size a box to a fixed height when its text can change. Measure the text, then size the box.

## 5. Images

- Every educational PDF gets at least one picture that helps the learning.
- Every image has a credit line under it: Title, Author, Source, License (TASL). Example: "Piano keys, by Jane Doe, Wikimedia Commons, CC BY 4.0."
- Open-licensed images first (Wikimedia Commons, public domain). Drawings you make yourself need only "Image: made for this handout."
- Images keep their shape. Never stretch.

## 6. Words

- Plain text in the content: no HTML tags showing, no "None" or "undefined", no boxes where letters should be.
- For Chinese, Japanese or Korean text, register a font that has those characters before building (ask Sage).
- No bold for emphasis in body text, no em dashes.
- Write for the reader's level. Cosmo checks the voice.

## 7. The final check (Sage, every time)

1. Build the PDF.
2. Turn every page into a picture and look at it. Text checks can't see a table hanging off the page or a big blank gap; your eyes can.
3. Check the page count is what was asked for.
4. Footer on every page, no teammate names, credits under images.
5. Only then hand it over.

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
