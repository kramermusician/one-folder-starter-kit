# Slideshow SOP

Owner: Larry builds, Cosmo checks the words. Read this before making any HTML slideshow.

## How it should feel

- Warm, casual, alive. Would the room smile or slump?
- One idea per slide. Never a paragraph on a slide.
- My voice: "you", "we", contractions, real questions. Prompts are invitations, not assignments.
- Big type (28 pt and up), lots of space, a warm palette (cream, sage, ocean, earth tones).
- Something moves or gets revealed: hold back an answer and show it on the next click.

## How it's built

- One folder per deck, inside the course or project it belongs to (belongs-to test in CLAUDE.md).
- Start from `tools/slideshow/example-deck/`: copy the whole folder, rename it, change the slides.
- Every slide is a `<section data-id="...">` with an `<h1>`. The data-id never changes once the deck is used, because notes hang on it.
- Arrow keys and space move. `t` opens Contents. `n` opens the notes box.

## The feedback box (every deck)

Each deck has a notes box under the slides. While I teach or rehearse, I type what worked and what to change. It saves to `<deck>-notes.json` beside the deck.

- Start the deck with its `run.sh` (double-click won't save notes; run.sh starts the little server that does).
- Before changing an existing deck, read its notes file first. Those notes are my change requests.
- The Plan notes and Apply notes buttons ask Claude to plan, then make, the changes my notes ask for.

## Rules learned

New rules go here, newest at the bottom, one line each, like: - (My rule, YYYY-MM-DD) The rule.
