# Start here

Hi! This folder becomes your own system: one folder that holds your notes, your people, your to-do list, your teaching materials, and a small team of AI helpers who learn your rules.

You talk into your phone. A minute later the reminder is on your list, the person you mentioned has a page, and the idea is filed. Then you coach it, and every week it gets better.

## Setup, in order

1. Double-click `01-check-my-mac.command`. If your Mac says it can't open it, right-click it and choose Open. On newer Macs, go to System Settings, Privacy & Security, scroll down, and click Open Anyway. You only do this once; after that the other files open normally.
2. Double-click `02-install-claude-code.command` (Codex users: `02-install-codex.command`). No Homebrew needed.
3. Double-click `open-claude.command` and log in. Say hi.
4. Put your homework in `about-me.md`, then ask Claude to fill in `CLAUDE.md`.
5. Double-click `03-install-whisper.command`. About five minutes.
6. Double-click `04-start-watcher.command`. You'll see "watcher running".
7. Put the record button on your phone: open `phone-shortcut-link.txt`.
8. Record a memo. Find it in `team-inbox/transcripts/` and the reminder in `todo.md`.

## Every session ends the same way

Type `/close-chat` (Codex: `$close-chat`). The system writes what got done into `journal.md`, logs any misses in `past-work/failure-journal.md`, and names the next step. Skip it and the next session starts from zero.

## Keep your files safe

Claude and Codex can only change files inside this folder without asking. Reading is looser: by default they can see other files on the computer. This kit closes that gap for Claude (the settings block your Documents, Desktop, Pictures, passwords and keys). For both tools:

- Always open the tool from inside this folder, never from your home folder.
- Keep personal files outside this folder. Never put passwords or keys in it.
- Read every permission question. If it asks to go outside this folder, say no unless you know why.
- Never use full-access, "yolo" or auto-approve modes. Codex: stay in the normal mode (workspace-write, asks first, network off).
- Safest of all: a separate user account on your Mac with no personal files in it.

## Using Codex instead of Claude

Everything works the same with Codex (OpenAI). Skip steps 2 and 3 and instead:

- Double-click `02-install-codex.command` (or paste this one line in Terminal: `curl -fsSL https://chatgpt.com/codex/install.sh | sh`). No Homebrew or Node needed.
- Open Terminal in this folder and type `codex`. The first time, choose Sign in with ChatGPT.
- Codex reads `AGENTS.md`, which points it to `CLAUDE.md`. Same brain, different reader.
- Wherever this page says "Claude", read "Codex". The watcher finds Codex on its own when Claude isn't installed.

## What's where

- `CLAUDE.md`: the brain. Claude reads it every session.
- `todo.md`: open work. `done.md`: finished work.
- `people/`, `projects/`, `courses/`, `topics/`: one page per thing worth remembering.
- `team/`: your AI teammates. Rename them, give them rules.
- `SOPs/`: how things get made (PDFs, slideshows, memos).
- `team-inbox/`: Team Inbox. Drop anything here for the system to look at. Memos arrive in `team-inbox/voice/`.
- `owners-inbox/_New/`: Owner's Inbox. New things the system makes, waiting for your review.
- `knowledge/`: your finished, approved work. One folder per course. Only you move things in.
- `past-work/`: work that missed your standard, plus `failure-journal.md`. Nothing is deleted; every miss becomes a rule.

## Talk to it in Spanish

Claude and Whisper both work in Spanish and English. Write or speak whichever feels natural. Puedes escribirle en español.

## When something feels wrong

Say what was wrong and ask for a rule: "That was wrong because ___. Write a rule into the right teammate's file so it never happens again, and show me the rule." That sentence is how the system learns.

Kramer
