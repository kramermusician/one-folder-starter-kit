# Start here

Hi! This folder becomes your own system: one folder that holds your notes, your people, your to-do list, your teaching materials, and a small team of AI helpers who learn your rules.

You talk into your phone. A minute later the reminder is on your list, the person you mentioned has a page, and the idea is filed. Then you coach it, and every week it gets better.

## Setup, in order

1. Double-click `01-check-my-mac.command`. If your Mac says it can't open it, right-click it and choose Open. On newer Macs, go to System Settings, Privacy & Security, scroll down, and click Open Anyway. You only do this once; after that the other files open normally.
2. Double-click `02-install-claude-code.command`.
3. Double-click `open-claude.command` and log in. Say hi.
4. Put your homework in `about-me.md`, then ask Claude to fill in `CLAUDE.md`.
5. Double-click `03-install-whisper.command`. About five minutes.
6. Double-click `04-start-watcher.command`. You'll see "watcher running".
7. Put the record button on your phone: open `phone-shortcut-link.txt`.
8. Record a memo. Find it in `inbox/transcripts/` and the reminder in `todo.md`.

## What's where

- `CLAUDE.md`: the brain. Claude reads it every session.
- `todo.md`: open work. `done.md`: finished work.
- `people/`, `projects/`, `courses/`, `topics/`: one page per thing worth remembering.
- `team/`: your AI teammates. Rename them, give them rules.
- `SOPs/`: how things get made (PDFs, slideshows, memos).
- `inbox/`: where memos arrive and become text.
- `output/_New/`: new things Claude makes, until you file them.

## Talk to it in Spanish

Claude and Whisper both work in Spanish and English. Write or speak whichever feels natural. Puedes escribirle en español.

## When something feels wrong

Say what was wrong and ask for a rule: "That was wrong because ___. Write a rule into the right teammate's file so it never happens again, and show me the rule." That sentence is how the system learns.

Kramer
