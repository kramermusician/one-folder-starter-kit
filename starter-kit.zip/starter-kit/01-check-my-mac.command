#!/bin/bash
# Step 1: check this Mac and get the folder ready. Safe to run as many times as you like.
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
NAME="$(basename "$HERE")"
problems=0

echo ""
echo "Checking your Mac for $NAME ..."
echo ""

# 1. The chip
if [ "$(uname -m)" = "arm64" ]; then
  echo "  OK   Apple chip ($(sysctl -n machdep.cpu.brand_string 2>/dev/null)). Whisper will be fast."
else
  echo "  NOTE Intel chip. Everything still works, but transcribing a memo takes longer (about the length of the memo)."
fi

# 2. macOS version
ver="$(sw_vers -productVersion)"
major="${ver%%.*}"
if [ "$major" -ge 13 ] 2>/dev/null; then
  echo "  OK   macOS $ver"
else
  echo "  FIX  macOS $ver is old. Update to macOS 13 or newer (Apple menu, System Settings, General, Software Update)."
  problems=$((problems+1))
fi

# 3. Inside Dropbox?
case "$HERE" in
  *"/Dropbox"*|*"/CloudStorage/Dropbox"*)
    echo "  OK   This folder is inside Dropbox, so your phone can drop memos into it." ;;
  *)
    echo "  FIX  This folder is not inside Dropbox. Move it into your Dropbox folder, then run this again."
    problems=$((problems+1)) ;;
esac

# 4. Free disk space (the speech model needs about 2 GB)
free_gb=$(df -g "$HOME" | awk 'NR==2 {print $4}')
if [ "${free_gb:-0}" -ge 5 ]; then
  echo "  OK   ${free_gb} GB free"
else
  echo "  FIX  Only ${free_gb} GB free. Clear at least 5 GB before step 4."
  problems=$((problems+1))
fi

# 5. Let the other setup files open with a double-click
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null
chmod +x "$HERE"/*.command 2>/dev/null
echo "  OK   The other setup files will now open with a double-click."

# 6. Claude's permission settings (a hidden folder, so it doesn't come along when you drag files in Finder)
if [ ! -f .claude/settings.json ] && [ -f tools/claude-settings.json ]; then
  mkdir -p .claude && cp tools/claude-settings.json .claude/settings.json
fi
echo "  OK   Claude's settings are in place."

# 7. Make the folders your system expects
mkdir -p inbox/voice inbox/transcripts inbox/processed people projects courses topics team SOPs output/_New
echo "  OK   Folders are in place."

echo ""
echo "One thing to do by hand, once:"
echo "  In Finder, right-click the $NAME folder and choose 'Make available offline'."
echo "  Background helpers (like the memo watcher) can't open files that live only in the cloud."
echo ""
if [ "$problems" -eq 0 ]; then
  echo "CHECK: all good. Next, double-click 02-install-claude-code.command"
else
  echo "CHECK: $problems thing(s) to fix above, then run this again."
fi
echo ""
