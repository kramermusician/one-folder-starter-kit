#!/bin/bash
# Step 2 (Codex users only): install Codex, OpenAI's official installer. Safe to run twice.
cd "$(dirname "$0")" || exit 1
echo ""
echo "Installing Codex. This takes a minute or two. No Homebrew or Node needed."
echo ""
curl -fsSL https://chatgpt.com/codex/install.sh | sh
if ! grep -q '.local/bin' "$HOME/.zshrc" 2>/dev/null; then
  echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
fi
export PATH="$HOME/.local/bin:$PATH"
echo ""
if command -v codex >/dev/null 2>&1; then
  echo "CHECK: Codex $(codex --version 2>/dev/null) is installed."
  echo ""
  echo "Next: open Terminal in your folder and type: codex"
  echo "The first time, choose Sign in with ChatGPT."
else
  echo "CHECK: something went wrong. Take a photo of this window and show Kramer."
fi
echo ""
