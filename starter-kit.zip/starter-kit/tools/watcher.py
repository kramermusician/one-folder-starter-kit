"""The memo watcher. Runs in the background (installed by 04-start-watcher.command).

Every few seconds it looks in team-inbox/voice/ for a new recording. For each one it:
  1. waits until the file has finished arriving from your phone,
  2. turns it into text with Whisper (on this Mac) and saves team-inbox/transcripts/<time>-<words>.md,
  3. moves the audio to team-inbox/processed/ (nothing is ever deleted),
  4. asks Claude to route it, following tools/route-prompt.md (to-dos, people, ideas).

Pause it: make an empty file called watcher-off inside team-inbox/. Delete that file to resume.
Log: team-inbox/watcher.log

    ~/.onefolder/venv/bin/python watcher.py <your-system-folder>
"""
import datetime
import errno
import os
import re
import shutil
import subprocess
import sys
import time
import unicodedata

AUDIO = (".m4a", ".mp3", ".wav", ".caf", ".aac", ".mp4")
POLL = 5            # seconds between looks
SETTLE = 2          # same size on this many looks in a row = finished arriving
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def find_claude():
    for p in (os.path.expanduser("~/.local/bin/claude"), "/opt/homebrew/bin/claude", "/usr/local/bin/claude"):
        if os.path.exists(p):
            return p
    return shutil.which("claude")


def find_codex():
    import glob
    cands = [os.path.expanduser("~/.local/bin/codex"), os.path.expanduser("~/.npm-global/bin/codex"),
             "/opt/homebrew/bin/codex", "/usr/local/bin/codex"]
    cands += sorted(glob.glob(os.path.expanduser("~/.nvm/versions/node/*/bin/codex")), reverse=True)
    for p in cands:
        if os.path.exists(p):
            return p
    return shutil.which("codex")


class Watcher:
    def __init__(self, folder):
        self.root = os.path.abspath(folder)
        self.voice = os.path.join(self.root, "team-inbox", "voice")
        self.trans = os.path.join(self.root, "team-inbox", "transcripts")
        self.done = os.path.join(self.root, "team-inbox", "processed")
        self.logf = os.path.join(self.root, "team-inbox", "watcher.log")
        self.off = os.path.join(self.root, "team-inbox", "watcher-off")
        for d in (self.voice, self.trans, self.done):
            os.makedirs(d, exist_ok=True)
        self.sizes = {}
        self.paused_logged = False

    def log(self, msg):
        line = f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}  {msg}"
        print(line, flush=True)
        try:
            with open(self.logf, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except OSError:
            pass

    # Dropbox keeps some files only in the cloud. A background process gets "Resource deadlock
    # avoided" (EDEADLK) when it reads one. Opening it in a stock app makes Dropbox download it.
    def make_local(self, path):
        try:
            with open(path, "rb") as f:
                f.read(16)
            return True
        except OSError as e:
            if e.errno != errno.EDEADLK:
                raise
        self.log(f"downloading from Dropbox first: {os.path.basename(path)}")
        was_running = subprocess.run(["pgrep", "-x", "QuickTime Player"], capture_output=True).returncode == 0
        subprocess.run(["/usr/bin/open", "-g", "-a", "QuickTime Player", path])
        ok = False
        for _ in range(60):
            time.sleep(1)
            try:
                with open(path, "rb") as f:
                    f.read(16)
                ok = True
                break
            except OSError:
                pass
        if not was_running:
            subprocess.run(["osascript", "-e", 'quit app "QuickTime Player"'], capture_output=True)
        return ok

    def ready_files(self):
        out = []
        try:
            names = sorted(os.listdir(self.voice))
        except OSError:
            return out
        for n in names:
            if n.startswith(".") or not n.lower().endswith(AUDIO):
                continue
            p = os.path.join(self.voice, n)
            try:
                size = os.path.getsize(p)
            except OSError:
                continue
            seen, count = self.sizes.get(p, (None, 0))
            count = count + 1 if (size == seen and size > 0) else 0
            self.sizes[p] = (size, count)
            if count >= SETTLE:
                out.append(p)
        return out

    def process(self, path):
        from transcribe import transcribe
        name = os.path.basename(path)
        self.log(f"new memo: {name}")
        if not self.make_local(path):
            self.log(f"could not read {name} yet; will try again")
            return
        try:
            text, lang = transcribe(path)
        except Exception as e:  # keep running whatever happens
            self.log(f"transcribe failed for {name}: {e}")
            return
        now = datetime.datetime.now()
        plain = unicodedata.normalize("NFKD", " ".join(text.lower().split()[:6])).encode("ascii", "ignore").decode()
        words = re.sub(r"[^a-z0-9]+", "-", plain).strip("-") or "memo"
        stem = f"{now:%Y-%m-%d-%H%M}-{words}"[:80]
        md = os.path.join(self.trans, stem + ".md")
        n = 2
        while os.path.exists(md):
            md = os.path.join(self.trans, f"{stem}-{n}.md"); n += 1
        with open(md, "w", encoding="utf-8") as f:
            f.write("---\n"
                    f"id: {os.path.splitext(os.path.basename(md))[0]}\n"
                    "type: transcript\n"
                    f"created: {now:%Y-%m-%d %H:%M}\n"
                    f"language: {lang}\n"
                    f"audio: team-inbox/processed/{name}\n"
                    "routed: pending\n"
                    "people: []\n"
                    "---\n\n"
                    f"{text}\n")
        dest = os.path.join(self.done, name)
        if os.path.exists(dest):
            dest = os.path.join(self.done, f"{now:%Y%m%d-%H%M%S}-{name}")
        shutil.move(path, dest)
        self.sizes.pop(path, None)
        self.log(f"transcribed ({lang}): {os.path.relpath(md, self.root)}")
        self.route(md)

    def route(self, md):
        claude = find_claude()
        codex = None if claude else find_codex()
        if not claude and not codex:
            self.log("Neither Claude Code nor Codex found, so this memo is transcribed but not routed yet")
            return
        rel = os.path.relpath(md, self.root)
        prompt_file = os.path.join(self.root, "tools", "route-prompt.md")
        try:
            with open(prompt_file, encoding="utf-8") as f:
                prompt = f.read()
        except OSError:
            with open(os.path.join(HERE, "route-prompt.md"), encoding="utf-8") as f:  # backup copy
                prompt = f.read()
        prompt += f"\n\nRight now it is {datetime.datetime.now():%Y-%m-%d %H:%M} ({datetime.date.today():%A}). The transcript to route is: {rel}\n"
        if claude:
            cmd = [claude, "-p", prompt,
                   "--permission-mode", "acceptEdits",
                   "--allowedTools", "Read,Write,Edit,Glob,Grep",
                   "--disallowedTools", "Bash,WebFetch,WebSearch",
                   "--output-format", "text"]
            engine = "Claude"
        else:
            # Codex: may edit files inside this folder only, no network.
            cmd = [codex, "exec", "--sandbox", "workspace-write",
                   "--skip-git-repo-check", "-C", self.root, prompt]
            engine = "Codex"
        self.log(f"routing with {engine}: {rel}")
        try:
            r = subprocess.run(cmd, cwd=self.root, capture_output=True, text=True, timeout=900)
            tail = (r.stdout or r.stderr or "").strip().splitlines()[-3:]
            self.log("routed: " + " | ".join(tail) if r.returncode == 0 else f"routing failed ({r.returncode}): {' | '.join(tail)}")
        except subprocess.TimeoutExpired:
            self.log("routing took over 15 minutes and was stopped; the transcript is safe")

    def retry_pending(self):
        for n in sorted(os.listdir(self.trans)):
            p = os.path.join(self.trans, n)
            if n.endswith(".md"):
                try:
                    with open(p, encoding="utf-8") as f:
                        head = f.read(600)
                except OSError:
                    continue
                if "routed: pending" in head:
                    self.route(p)

    def run(self):
        self.log(f"watcher running, watching {os.path.relpath(self.voice, os.path.dirname(self.root))}")
        self.retry_pending()
        while True:
            if os.path.exists(self.off):
                if not self.paused_logged:
                    self.log("paused (team-inbox/watcher-off exists)"); self.paused_logged = True
            else:
                if self.paused_logged:
                    self.log("resumed"); self.paused_logged = False
                for p in self.ready_files():
                    self.process(p)
            time.sleep(POLL)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: watcher.py <your-system-folder>")
    Watcher(sys.argv[1]).run()
