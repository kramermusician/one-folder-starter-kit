"""Turn an audio file into text, on this Mac, with no internet after the first download.

Apple chip: mlx-whisper with whisper-large-v3-turbo (fast, very accurate).
Intel chip: faster-whisper with the "small" model (slower, still good).
Language is detected on its own, so English and Spanish both work.

    ~/.onefolder/venv/bin/python tools/transcribe.py <audio-file>
"""
import os
import platform
import sys

VENV_BIN = os.path.expanduser("~/.onefolder/venv/bin")
os.environ["PATH"] = VENV_BIN + os.pathsep + os.environ.get("PATH", "")  # ffmpeg lives here

APPLE_MODEL = "mlx-community/whisper-large-v3-turbo"
INTEL_MODEL = "small"


def transcribe(path):
    """Return (text, language_code)."""
    if platform.machine() == "arm64":
        import mlx_whisper
        r = mlx_whisper.transcribe(path, path_or_hf_repo=APPLE_MODEL, condition_on_previous_text=False)
        text = " ".join(s["text"].strip() for s in r.get("segments", [])) or r.get("text", "")
        return text.strip(), r.get("language", "")
    from faster_whisper import WhisperModel
    model = WhisperModel(INTEL_MODEL, device="cpu", compute_type="int8")
    segments, info = model.transcribe(path, vad_filter=True)
    return " ".join(s.text.strip() for s in segments).strip(), info.language


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: transcribe.py <audio-file>")
    text, lang = transcribe(sys.argv[1])
    print(f"[{lang}] {text}")
