"""The file catalog: one index of every file in this folder, so Claude can find things fast.

    python3 tools/catalog.py              rebuild file-catalog.json
    python3 tools/catalog.py find harmony list files whose name, title or tags match

Standard library only. Safe to run any time.
"""
import datetime
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "file-catalog.json")
SKIP_DIRS = {".git", ".claude", ".obsidian", "__pycache__", "processed", "node_modules", "deck-agent", "notes-cleared"}
SKIP_FILES = {"file-catalog.json", ".DS_Store"}


def frontmatter(path):
    """Read title and tags from a markdown file's top block, if it has one."""
    title, tags, kind = "", [], ""
    try:
        with open(path, encoding="utf-8") as f:
            head = f.read(3000)
    except (OSError, UnicodeDecodeError):
        return title, tags, kind
    m = re.match(r"---\n(.*?)\n---", head, re.S)
    if m:
        for line in m.group(1).splitlines():
            k, _, v = line.partition(":")
            v = v.strip()
            if k == "name":
                title = v
            elif k == "type":
                kind = v
            elif k == "tags":
                tags = [t.strip() for t in v.strip("[]").split(",") if t.strip()]
    if not title:
        h = re.search(r"^# (.+)$", head, re.M)
        if h:
            title = h.group(1).strip()
    return title, tags, kind


def build():
    files = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for n in filenames:
            if n in SKIP_FILES or n.startswith("."):
                continue
            p = os.path.join(dirpath, n)
            rel = os.path.relpath(p, ROOT)
            try:
                st = os.stat(p)
            except OSError:
                continue
            title, tags, kind = frontmatter(p) if n.endswith(".md") else ("", [], "")
            files.append({
                "path": rel,
                "folder": os.path.dirname(rel) or ".",
                "ext": os.path.splitext(n)[1].lstrip(".").lower(),
                "type": kind,
                "title": title,
                "tags": tags,
                "size": st.st_size,
                "modified": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d"),
            })
    files.sort(key=lambda f: f["path"])
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"built": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "count": len(files), "files": files},
                  f, indent=1, ensure_ascii=False)
    print(f"Catalog rebuilt: {len(files)} files in file-catalog.json")


def find(words):
    if not os.path.exists(OUT):
        build()
    with open(OUT, encoding="utf-8") as f:
        files = json.load(f)["files"]
    q = [w.lower() for w in words]
    hits = [f for f in files if all(w in " ".join([f["path"], f["title"], " ".join(f["tags"])]).lower() for w in q)]
    for f in hits:
        print(f"{f['modified']}  {f['path']}" + (f"  ({f['title']})" if f["title"] else ""))
    print(f"{len(hits)} match(es)")


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "find":
        find(sys.argv[2:])
    else:
        build()
