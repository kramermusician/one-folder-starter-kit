"""PDF template: a one-page handout that follows every rule in SOPs/PDF_SOP.md.

Copy this file, change the CONTENT section, keep the rest. Run it with:

    ~/.onefolder/venv/bin/python tools/pdf_template.py

It writes owners-inbox/_New/sample-handout.pdf. If reportlab is missing, it installs it into ~/.onefolder/venv.
"""
import os
import subprocess
import sys

try:
    import reportlab  # noqa: F401
except ImportError:
    uv = next((p for p in (os.path.expanduser("~/.local/bin/uv"), "/opt/homebrew/bin/uv") if os.path.exists(p)), "uv")
    subprocess.run([uv, "pip", "install", "-q", "-p", sys.executable, "reportlab"], check=True)

from reportlab.graphics.shapes import Circle, Drawing, Line, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ---------- set these once ----------
FOOTER = "Your Name - Your School - Your Department"   # your name only; never a teammate's
ACCENT = colors.HexColor("#5f7f8f")                     # one accent color
OUT = os.path.join(ROOT, "owners-inbox", "_New", "sample-handout.pdf")

# ---------- page and type (SOP section 1) ----------
PAGE_W, PAGE_H = letter
MARGIN = 0.75 * inch
CONTENT_W = PAGE_W - 2 * MARGIN
TITLE = ParagraphStyle("title", fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=ACCENT, spaceAfter=6)
HEAD = ParagraphStyle("head", fontName="Helvetica-Bold", fontSize=12, leading=15, spaceBefore=10, spaceAfter=4)
BODY = ParagraphStyle("body", fontName="Helvetica", fontSize=10.5, leading=14, spaceAfter=6)
CELL = ParagraphStyle("cell", fontName="Helvetica", fontSize=9.5, leading=12)
CELL_HEAD = ParagraphStyle("cellhead", parent=CELL, fontName="Helvetica-Bold")
CREDIT = ParagraphStyle("credit", fontName="Helvetica-Oblique", fontSize=8, leading=10, textColor=colors.grey, alignment=TA_CENTER)
MIN_COL = 1.2 * inch   # SOP section 3: no column narrower than this for words


# ---------- table helpers (SOP section 3) ----------
def fit_columns(rows, total=CONTENT_W, min_col=MIN_COL):
    """Share the width out by how much text each column holds, never below min_col."""
    ncol = len(rows[0])
    need = [max(stringWidth(str(r[c]), CELL.fontName, CELL.fontSize) for r in rows) for c in range(ncol)]
    need = [min(n, total) + 12 for n in need]          # 12 pt padding; one long cell can't take everything
    scale = total / sum(need)
    widths = [max(min_col, n * scale) for n in need]
    extra = sum(widths) - total                        # take back what the minimums added
    if extra > 0:
        flex = [i for i, w in enumerate(widths) if w > min_col]
        room = sum(widths[i] - min_col for i in flex) or 1
        for i in flex:
            widths[i] -= extra * (widths[i] - min_col) / room
    return widths


def check_table(rows, widths):
    """Warn when a single word is wider than its column (it would overflow). Fix before building."""
    warnings = []
    for r, row in enumerate(rows):
        for c, cell in enumerate(row):
            for word in str(cell).split():
                if stringWidth(word, CELL.fontName, CELL.fontSize) > widths[c] - 12:
                    warnings.append(f"row {r + 1}, column {c + 1}: '{word}' is too wide for its column")
    return warnings


def make_table(rows):
    widths = fit_columns(rows)
    for w in check_table(rows, widths):
        print("TABLE WARNING:", w)
    data = [[Paragraph(str(x), CELL_HEAD if i == 0 else CELL) for x in row] for i, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1)    # header repeats if it runs to page 2
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8efe9")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#b9c4bb")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6), ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def picture():
    """A small drawing made in code, so it needs no license. Real photos need a TASL credit."""
    d = Drawing(CONTENT_W, 70)
    xs = [CONTENT_W * f for f in (0.12, 0.37, 0.62, 0.87)]
    labels = ["Record", "Transcribe", "Route", "Act"]
    for i, x in enumerate(xs):
        if i:
            d.add(Line(xs[i - 1] + 22, 42, x - 22, 42, strokeColor=colors.HexColor("#b9c4bb"), strokeWidth=2))
        d.add(Circle(x, 42, 20, fillColor=ACCENT if i % 2 == 0 else colors.HexColor("#6f9470"), strokeColor=None))
        d.add(String(x, 38, str(i + 1), fontName="Helvetica-Bold", fontSize=13, fillColor=colors.white, textAnchor="middle"))
        d.add(String(x, 8, labels[i], fontName="Helvetica", fontSize=10, textAnchor="middle"))
    return d


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica-Oblique", 8)
    canvas.setFillColor(colors.grey)
    canvas.drawCentredString(PAGE_W / 2, 0.45 * inch, FOOTER)
    canvas.restoreState()


# ---------- CONTENT: change this part ----------
def story():
    rows = [
        ["Part", "What it does", "Where you see it"],
        ["Watcher", "Notices a new recording in your Dropbox inbox and waits until it has fully arrived.", "team-inbox/watcher.log"],
        ["Whisper", "Turns speech into text on your own Mac, in English or Spanish.", "team-inbox/transcripts/"],
        ["Router", "Reads the text and files reminders, people and ideas where they belong.", "todo.md, people/, topics/"],
        ["You", "Read, correct, and coach. Every fix becomes a rule.", "team/ and SOPs/"],
    ]
    return [
        Paragraph("How a Voice Memo Becomes a To-Do", TITLE),
        Paragraph("You talk, your system listens, and a minute later the reminder is on your list. "
                  "Here is what happens in between.", BODY),
        KeepTogether([picture(), Spacer(1, 2), Paragraph("Image: made for this handout.", CREDIT)]),
        # A heading always travels with what follows it (SOP section 4)
        KeepTogether([Paragraph("The four parts", HEAD), make_table(rows)]),
        KeepTogether([
            Paragraph("Try it", HEAD),
            Paragraph("Record: remind me to buy new strings on Friday. Then open todo.md and find the line. "
                      "If anything landed in the wrong place, tell Claude what was wrong and ask for a rule.", BODY),
        ]),
    ]


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc = SimpleDocTemplate(OUT, pagesize=letter, leftMargin=MARGIN, rightMargin=MARGIN,
                            topMargin=MARGIN, bottomMargin=MARGIN, title="How a Voice Memo Becomes a To-Do")
    doc.build(story(), onFirstPage=footer, onLaterPages=footer)
    try:
        from pypdf import PdfReader
        pages = len(PdfReader(OUT).pages)
    except ImportError:
        pages = "?"
    print(f"Built {os.path.relpath(OUT, ROOT)} ({pages} page(s)). Now look at every page before calling it done.")
