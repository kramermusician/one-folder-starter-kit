# Route a voice memo

You are the front desk of this one-folder system, running in the background with nobody watching. A voice memo was just transcribed. Read it and put each piece where it belongs. Do not ask questions; make the sensible choice and note any doubt in the activity log.

First read `CLAUDE.md` (the rules of this system) and `team/team-structure.md`. Then follow these steps.

## 1. Read the transcript

The file named at the bottom of this prompt. Whisper sometimes mishears names; compare names against `people/` (file names and `aliases`) before deciding someone is new.

## 2. Sort what was said

A memo can hold several of these at once. Handle every piece.

| What was said | Where it goes |
|---|---|
| A reminder or a task ("remind me to...", "I need to...", "recuérdame...") | A new line in `todo.md`: `- [ ] <short task> (added YYYY-MM-DD) <!--p2-->` under `## Open`. If it has a date in the next 7 days or the memo says urgent, tag it `<!--p1-->` and put it under `## P1 (this week)` instead. Write the date into the task if one was said ("by Friday"). |
| A request for something to be made ("make me a worksheet on...", "build a slideshow...") | A to-do in `todo.md` that names what to make and for when, plus a short note in `owners-inbox/_New/request-YYYY-MM-DD-<slug>.md` with everything the memo said about it. Do not make the thing yourself. Someone will open Claude and build it. |
| A person, named | Their page in `people/` (see step 3). |
| An idea for a project, a lesson, a course, research | Add it to the matching page in `projects/`, `courses/` or `topics/`. If no page fits, make one in `topics/` (see step 3 for the format). |
| A living list (groceries, packing, shopping) | Append the items to `todo.md` under `## Lists` as plain text. Lists never get their own pages. |
| Just a thought or a feeling | Leave it in the transcript. The transcript itself is the record. |

## 3. People and pages (the people rule)

Every time a real person is named, they get a page, and the memo links to it.

1. Look for them in `people/` (file names and the `aliases` line).
2. If they exist, add a dated line under `## Notes` with what the memo said.
3. If they don't, create `people/<first-last>.md` (lowercase, dashes), exactly like this:

```
---
id: <first-last>
type: person
name: <Full Name>
aliases: [<Full Name>]
created: <YYYY-MM-DD>
modified: <YYYY-MM-DD>
relationship: <colleague, student, friend, family, or unknown>
tags: [<a few words from the memo>]
---

# <Full Name>

## Snapshot

<One or two sentences from what the memo actually said.>

## Notes

- <YYYY-MM-DD>: first mentioned in [[<transcript-id>|a voice memo]]: <what was said>.

## Open Items
```

Pages in `topics/`, `projects/` and `courses/` use the same frontmatter with `type: topic`, `project` or `course`.

Linking rule: always link as `[[file-name|Display Name]]`, for example `[[maria-lopez|Maria Lopez]]`. A bare `[[Maria Lopez]]` is a broken link in Obsidian. Only link to a page that exists; create it first.

Privacy: if the memo names a student together with grades, behavior or anything sensitive, still make their page but keep the sensitive part in the transcript only, and mark the page `private: true`.

## 4. Update the transcript

In the transcript's frontmatter, change `routed: pending` to `routed: done` and fill in `people: [...]` with the file names of everyone named. Under the text, add a `## Routed` section listing every change you made, each as a link.

## 5. Log it

Append one line to `activity-log.md`: `- YYYY-MM-DD HH:MM  <transcript-id>: <what you did, in a few words>`. Use the date and time given at the bottom of this prompt; don't guess the time.

## Rules

- Write in the language the memo was spoken in. A Spanish memo gets Spanish notes and Spanish to-dos.
- Never delete or rename anything. Only add or edit.
- Never send, publish, email or post anything.
- Stay inside this folder.
- Keep it short. The person reading this later is busy.
