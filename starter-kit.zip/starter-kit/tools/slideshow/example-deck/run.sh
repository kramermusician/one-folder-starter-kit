#!/bin/bash
# Starts this deck with its feedback box. Safe to run twice. Change PORT if another deck uses it.
cd "$(dirname "$0")" || exit 1
PORT=8601
PY="$HOME/.onefolder/venv/bin/python"; [ -x "$PY" ] || PY=python3
NOTES="$(basename "$(pwd)")-notes.json"
if ! curl -s -o /dev/null "http://localhost:$PORT/notes"; then
  nohup "$PY" ../notes_server.py --dir . --notes "$NOTES" --port $PORT > /dev/null 2>&1 &
  sleep 1
fi
open "http://localhost:$PORT/"
