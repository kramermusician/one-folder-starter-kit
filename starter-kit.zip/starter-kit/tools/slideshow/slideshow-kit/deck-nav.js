// Deck navigation for every HTML slideshow: a small "Next up:" line at the bottom and a
// Contents button (or t) that lists every slide and jumps to one. 
// Served by slideshow_notes_server.py at /_kit/deck-nav.js, so a deck needs no copy of it.
// The deck supplies SLIDES (each with .title), idx and render(); it calls navOnRender() at the end
// of render() and navKey(e) from its keydown handler, both guarded with typeof so the deck still
// runs if it is opened without the server.
(function () {
  const bar = document.createElement("div");
  bar.id = "navBar";
  bar.innerHTML = `<div id="navLeft"><button id="navTocBtn" title="Contents (t)">&#9776; Contents</button></div><div id="navNext"></div>`;
  const anchor = document.getElementById("brandBar") || document.getElementById("notesBar");
  if (anchor) anchor.parentNode.insertBefore(bar, anchor); else document.body.appendChild(bar);
  document.body.insertAdjacentHTML("beforeend", `<div id="navToc"><div id="navTocCard"><div id="navTocHead"><span>Contents</span><button id="navTocClose" title="Close (Esc)">&#10005;</button></div><ol id="navTocList"></ol></div></div>`);
  const toc = document.getElementById("navToc");
  const titleOf = s => (s.title || s.id || "").trim();

  window.navOnRender = function () {
    const nxt = SLIDES[idx + 1];
    document.getElementById("navNext").innerHTML = nxt ? `Next up: <b>${titleOf(nxt)}</b>` : "Last slide";
    if (toc.classList.contains("open")) navTocDraw();
    agentLine();
  };
  function navTocDraw() {
    document.getElementById("navTocList").innerHTML = SLIDES.map((s, i) =>
      `<li data-i="${i}" class="${i === idx ? "here" : ""}"><span class="n">${i + 1}</span>${titleOf(s)}</li>`).join("");
    const here = toc.querySelector("li.here"); if (here) here.scrollIntoView({ block: "center" });
  }
  window.navToc = function (on) { toc.classList.toggle("open", on); if (on) navTocDraw(); };
  // t opens and closes the contents; Escape closes it. Returns true when it used the key.
  window.navKey = function (e) {
    const open = toc.classList.contains("open");
    if (e.key === "t" || (open && e.key === "Escape")) { e.preventDefault(); navToc(!open); return true; }
    return false;
  };
  document.getElementById("navTocBtn").addEventListener("click", e => { e.stopPropagation(); navToc(!toc.classList.contains("open")); });
  document.getElementById("navTocClose").addEventListener("click", e => { e.stopPropagation(); navToc(false); });
  toc.addEventListener("click", e => {
    e.stopPropagation();
    const li = e.target.closest("li[data-i]");
    if (li) { idx = +li.dataset.i; navToc(false); render(); }
    else if (e.target === toc) navToc(false);
  });

  // ---------- notes agent: Plan notes, Apply notes, Clear all notes ----------
  // Press a button instead of telling a Claude session "I added notes".
  // The server (GET /agent) runs a headless Claude over the notes that are new since the last Apply.
  // Plan writes a plan onto each slide (read-only); Apply makes the changes. Each slide's plan or
  // reply shows above the notes box. Only drawn when the server has the agent, so old servers and
  // decks opened from Finder look as before.
  let agent = null, poll = null, wasRunning = false, clearArmed = null;
  const esc = s => String(s || "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const line = document.createElement("div");
  line.id = "navAgentNote";
  const notesBar = document.getElementById("notesBar");
  if (notesBar) notesBar.parentNode.insertBefore(line, notesBar); else document.body.appendChild(line);

  function agentLine() {
    const s = agent && SLIDES[idx] && agent.slides[SLIDES[idx].id];
    const parts = [];
    if (s && s.plan) parts.push(`<b>Claude's plan</b> ${esc(s.plan)}`);
    if (s && s.reply) parts.push(`<b>Claude</b> ${esc(s.reply)}`);
    line.innerHTML = parts.join("<br>");
    line.classList.toggle("show", parts.length > 0);
  }
  function agentDraw() {
    const n = agent.pending.length;
    const st = document.getElementById("navAgentState");
    document.getElementById("navPlan").disabled = document.getElementById("navApply").disabled = agent.running || !n;
    document.getElementById("navApply").textContent = n ? `Apply notes (${n})` : "Apply notes";
    document.getElementById("navClear").disabled = agent.running;
    if (agent.running) {
      const t = agent.elapsed || 0;
      st.innerHTML = `Claude is ${agent.mode === "plan" ? "planning" : "making the changes"}… ${Math.floor(t / 60)}:${String(t % 60).padStart(2, "0")}`;
    } else if (agent.last && wasRunning !== null) {
      st.innerHTML = esc(agent.last.summary) + (agent.last.mode === "apply" && agent.last.ok ? ` <button id="navReload">Reload</button>` : "");
    }
    agentLine();
  }
  async function agentFetch(path, opts) {
    const r = await fetch(path, opts);
    const j = await r.json().catch(() => ({}));
    if (j.available) agent = j;
    return { r, j };
  }
  async function agentRefresh() {
    try { await agentFetch("/agent"); } catch (_) { return; }
    if (!agent) return;
    if (wasRunning && !agent.running) clearInterval(poll), poll = null;
    wasRunning = agent.running;
    if (agent.running && !poll) poll = setInterval(agentRefresh, 3000);
    agentDraw();
  }
  // the deck saves notes a moment after typing stops; send its copy first so the last note counts
  async function flushNotes() {
    if (typeof notes !== "object" || !notes) return;
    try { await fetch("/notes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(notes) }); } catch (_) {}
  }
  async function agentStart(mode) {
    await flushNotes();
    const { j } = await agentFetch("/agent/" + mode, { method: "POST" });
    if (j.message) document.getElementById("navAgentState").textContent = j.message;
    wasRunning = false;
    agentRefresh();
  }
  async function clearAll(btn) {
    // two taps: the first arms it for four seconds, the second clears (a copy goes to notes-cleared/)
    if (!clearArmed) {
      btn.textContent = "Tap again to clear every note";
      btn.classList.add("armed");
      clearArmed = setTimeout(() => { clearArmed = null; btn.textContent = "Clear all notes"; btn.classList.remove("armed"); }, 4000);
      return;
    }
    clearTimeout(clearArmed); clearArmed = null;
    btn.textContent = "Clear all notes"; btn.classList.remove("armed");
    const { r, j } = await agentFetch("/notes/clear", { method: "POST" });
    if (!r.ok) { document.getElementById("navAgentState").textContent = j.message || "Could not clear the notes."; return; }
    if (typeof notes === "object" && notes) Object.keys(notes).forEach(k => delete notes[k]);
    const box = document.getElementById("notes"); if (box) box.value = "";
    document.getElementById("navAgentState").textContent = `Cleared ${j.cleared} notes. A copy is in notes-cleared/.`;
    agentRefresh();
  }
  (async function agentInit() {
    try { await agentFetch("/agent"); } catch (_) { return; }
    if (!agent) return;
    document.getElementById("navLeft").insertAdjacentHTML("beforeend",
      `<button id="navPlan" class="navTool" title="Claude reads the new notes and writes a plan on each slide. Changes nothing.">Plan notes</button>` +
      `<button id="navApply" class="navTool" title="Claude makes the changes the new notes ask for">Apply notes</button>` +
      `<button id="navClear" class="navTool" title="Empty every note on this deck (tap twice)">Clear all notes</button>` +
      `<span id="navAgentState"></span>`);
    const left = document.getElementById("navLeft");
    left.addEventListener("click", e => {
      const b = e.target.closest("button"); if (!b || b.id === "navTocBtn") return;
      e.stopPropagation();
      if (b.id === "navPlan") agentStart("plan");
      else if (b.id === "navApply") agentStart("apply");
      else if (b.id === "navClear") clearAll(b);
      else if (b.id === "navReload") location.reload();
    });
    // pending is counted on the server, so re-ask after typing in a notes box; otherwise a note
    // written after the page opened leaves Plan and Apply greyed out
    let typed = null;
    document.addEventListener("input", e => {
      if (!e.target.closest || !e.target.closest("textarea")) return;
      clearTimeout(typed);
      typed = setTimeout(async () => { await flushNotes(); agentRefresh(); }, 1500);
    });
    wasRunning = null;  // first draw: show nothing about runs from before this page opened
    agentDraw();
    wasRunning = agent.running;
    if (agent.running) poll = setInterval(agentRefresh, 3000);
  })();
})();
