#!/usr/bin/env python3
"""Reusable local server for HTML slideshows with a per-slide notes box.

Serves a folder and persists your slide notes to a JSON file via
GET/POST /notes. The HTML side POSTs the whole notes dict
({slideId: {slide, text, updated}}) after each edit.

Usage:
  slideshow_notes_server.py --dir <folder> --notes <file.json> --port <N>
                            [--store name=file.json ...] [--allow-origin <host> ...]

Every POST must come from the deck's own page: an Origin header, when present, has to be
localhost, 127.0.0.1, or a host given with --allow-origin (repeatable) or listed in the
SLIDESHOW_ALLOW_ORIGINS env var. Any other site gets 403. Requests with no Origin (curl, scripts) still pass.

Each optional --store adds GET/POST /store/<name>, a whole-dict JSON file the
deck owns (e.g. a quiz leaderboard), saved the same way as the notes.
It also serves the shared slideshow kit (slideshow-kit/ beside this script) at
/_kit/<file>, so every deck gets deck-nav.js / deck-nav.css without a copy.
POST /store/<name>?key=<k> replaces only that top-level key, merged on the
server under a lock, so two decks sharing one file never overwrite each other.
POST /notes/clear empties every note on the deck (the kit's Clear all notes button), after
copying the file to notes-cleared/<notes-stem>-<time>.json beside it.

Notes agent (a button instead of "I added notes, read them and do them"):
  GET  /agent         run state, Claude's per-slide plan or reply, and which notes are still pending
  POST /agent/plan    headless `claude -p`, read-only tools: writes a plan for each pending note
  POST /agent/apply   headless `claude -p` in auto mode with publish/push/deploy tools blocked: makes
                      the changes, following an approved plan where one exists
One run at a time, in --dir. Each run keeps its prompt, output and (Apply) a copy of the deck's
html/js/css from before it in <dir>/deck-agent/runs/. The deck-nav kit draws the buttons.

Each deck only needs a run.sh beside it (see example-deck/run.sh).
"""
import argparse
import datetime
import json
import os
import shutil
import subprocess
import tempfile
import threading
import time
from urllib.parse import parse_qs, unquote, urlsplit
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler

SCHEMAS = {
    "plan": {"type": "object", "required": ["slides"], "properties": {"slides": {"type": "array", "items": {
        "type": "object", "required": ["id", "plan"],
        "properties": {"id": {"type": "string"}, "plan": {"type": "string"}}}}}},
    "apply": {"type": "object", "required": ["slides", "summary"], "properties": {
        "summary": {"type": "string"},
        "slides": {"type": "array", "items": {
            "type": "object", "required": ["id", "done", "reply"],
            "properties": {"id": {"type": "string"}, "done": {"type": "boolean"}, "reply": {"type": "string"}}}}}},
}
COMMON = """This is a headless run started from a button in the owner's HTML slideshow. Nobody is watching,
so do not ask questions mid-run, and skip the CLAUDE.md startup protocol (no greeting, journal, brief or
team files unless a note needs them). Every other rule in CLAUDE.md and in this folder's CLAUDE.md or
README applies. The deck is the HTML file in this folder that holds the slides (usually index.html);
each slide's data-id is the note's id. The owner typed the notes as change requests.
Never publish, push, commit, deploy, email, post, or use the Artifact tool. Do not edit {notes},
anything in deck-agent/, or anything in notes-cleared/. Replies are plain text, one or two sentences,
no bold, no em dashes."""
PROMPTS = {
    "plan": COMMON + """

PLAN ONLY: change no file. Read the deck and, for each note below, write the plan you would follow:
what changes and where, plus anything the owner must decide first (an unclear ask, a wrong fact, a house
rule it would break, a cost like a long render). The owner reads these on the slides before pressing Apply.

Notes:
{items}""",
    "apply": COMMON + """

Make the change each note below asks for, matching the deck's existing code and style. Where a note
has an "approved_plan", follow it. If a note is unclear, contradicts a house rule, or needs an outward
action, leave it undone and use the reply to say what you need. Check your work (for example a headless
Chrome screenshot of the slide) before calling a note done. The summary is one sentence for the deck.

Notes:
{items}""",
}
# Outward actions the Apply run may never take, on top of the rules in its prompt.
BLOCKED = ["Artifact", "ArtifactData", "ArtifactComments", "WebFetch", "WebSearch",
           "Bash(git push:*)", "Bash(git commit:*)", "Bash(gh:*)", "Bash(firebase:*)", "Bash(npx firebase:*)",
           "Bash(./publish-live.sh:*)", "Bash(./release.sh:*)",
           "mcp__claude_ai_Gmail", "mcp__claude_ai_Google_Calendar", "mcp__claude_ai_Claude_Docs",
           "mcp__claude-in-chrome"]


def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(tmp, path)


class NotesAgent:
    """One headless Claude session at a time over the deck's pending notes.
    State lives in <dir>/deck-agent/state.json, apart from the notes file, because the deck rewrites
    the whole notes file on every keystroke. A note is pending until an Apply run reports it done;
    editing its text makes it pending again."""

    def __init__(self, here, notes_path, lock):
        self.here, self.notes_path, self.lock = here, notes_path, lock
        self.root = os.path.join(here, "deck-agent")
        self.state_path = os.path.join(self.root, "state.json")
        self.run = None

    def pending(self, notes, slides):
        return [k for k, v in notes.items()
                if isinstance(v, dict) and (v.get("text") or "").strip()
                and slides.get(k, {}).get("applied") != v.get("updated")]

    def status(self):
        st = read_json(self.state_path, {})
        slides = st.get("slides", {})
        out = {"available": True, "running": bool(self.run), "slides": slides, "last": st.get("last"),
               "pending": self.pending(read_json(self.notes_path, {}), slides)}
        if self.run:
            out.update(mode=self.run["mode"], elapsed=int(time.time() - self.run["t0"]))
        return out

    def forget_slides(self):
        st = read_json(self.state_path, {})
        if st.get("slides"):
            st["slides"] = {}
            write_json(self.state_path, st)

    def start(self, mode):
        if self.run:
            return False, "Claude is already working on this deck."
        notes = read_json(self.notes_path, {})
        slides = read_json(self.state_path, {}).get("slides", {})
        ids = self.pending(notes, slides)
        if not ids:
            return False, "No new notes to work on."
        items = []
        for k in ids:
            item = {"id": k, "slide": notes[k].get("slide", ""), "note": notes[k]["text"]}
            s = slides.get(k, {})
            if mode == "apply" and s.get("plan") and s.get("planned") == notes[k].get("updated"):
                item["approved_plan"] = s["plan"]
            items.append(item)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H%M%S")
        rdir = os.path.join(self.root, "runs", f"{stamp}-{mode}")
        os.makedirs(rdir)
        if mode == "apply":  # the deck's own files as they were, so a bad run is one copy back
            before = os.path.join(rdir, "before")
            os.makedirs(before)
            for name in os.listdir(self.here):
                if name.endswith((".html", ".js", ".css")) and os.path.isfile(os.path.join(self.here, name)):
                    shutil.copy2(os.path.join(self.here, name), before)
        prompt = PROMPTS[mode].format(notes=os.path.basename(self.notes_path),
                                      items=json.dumps(items, ensure_ascii=False, indent=2))
        with open(os.path.join(rdir, "prompt.txt"), "w", encoding="utf-8") as f:
            f.write(prompt)
        claude = shutil.which("claude") or os.path.expanduser("~/.local/bin/claude")
        cmd = [claude, "-p", prompt, "--output-format", "json", "--no-session-persistence",
               "--json-schema", json.dumps(SCHEMAS[mode])]
        if mode == "plan":
            cmd += ["--permission-mode", "dontAsk", "--allowedTools", "Read", "Grep", "Glob", "Bash(ls:*)"]
        else:
            cmd += ["--permission-mode", "auto", "--disallowedTools", *BLOCKED]
        stamps = {k: notes[k].get("updated") for k in ids}
        self.run = {"mode": mode, "t0": time.time()}
        threading.Thread(target=self.finish, args=(mode, cmd, rdir, stamps), daemon=True).start()
        return True, f"Claude is {'planning' if mode == 'plan' else 'applying'} {len(ids)} notes."

    def finish(self, mode, cmd, rdir, stamps):
        result, err = None, ""
        try:
            with open(os.path.join(rdir, "output.json"), "w") as out, open(os.path.join(rdir, "stderr.txt"), "w") as se:
                p = subprocess.run(cmd, cwd=self.here, stdout=out, stderr=se, timeout=3600)
            result = read_json(os.path.join(rdir, "output.json"), {}).get("structured_output")
            if p.returncode or not result:
                err = f"Claude stopped without a result (exit {p.returncode}); see deck-agent/runs/{os.path.basename(rdir)}."
        except subprocess.TimeoutExpired:
            err = "Claude was stopped after an hour."
        except Exception as e:  # keep the server up whatever happens
            err = f"Claude run failed: {e}"
        with self.lock:
            st = read_json(self.state_path, {})
            slides = st.setdefault("slides", {})
            done = 0
            for item in (result or {}).get("slides", []):
                k = item.get("id")
                if k not in stamps:
                    continue
                s = slides.setdefault(k, {})
                at = datetime.datetime.now().isoformat(timespec="seconds")
                if mode == "plan":
                    s.update(plan=item.get("plan", ""), planned=stamps[k], at=at)
                else:
                    s.update(reply=item.get("reply", ""), at=at)
                    if item.get("done"):
                        s["applied"] = stamps[k]
                        done += 1
            if mode == "plan":
                summary = err or f"Plan ready for {len(stamps)} notes. Read it on each slide, then press Apply."
            else:
                summary = err or f"Applied {done} of {len(stamps)} notes. {(result or {}).get('summary', '')}".strip()
            st["last"] = {"mode": mode, "ok": not err, "summary": summary,
                          "finished": datetime.datetime.now().isoformat(timespec="seconds")}
            write_json(self.state_path, st)
            self.run = None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--notes", required=True)
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--store", action="append", default=[], metavar="NAME=FILE")
    ap.add_argument("--allow-origin", action="append", default=[], metavar="HOST",
                    help="extra hostname allowed to POST")
    a = ap.parse_args()
    env_hosts = os.environ.get("SLIDESHOW_ALLOW_ORIGINS", "").replace(",", " ").split()
    allowed = {"localhost", "127.0.0.1"} | {h.strip().lower() for h in a.allow_origin + env_hosts if h.strip()}
    here = os.path.abspath(a.dir)
    notes_path = os.path.abspath(a.notes)
    paths = {"/notes": notes_path}
    for spec in a.store:
        name, _, file = spec.partition("=")
        paths["/store/" + name] = os.path.abspath(file)

    lock = threading.Lock()
    kit = os.path.join(os.path.dirname(os.path.abspath(__file__)), "slideshow-kit")
    agent = NotesAgent(here, notes_path, lock)

    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=here, **kwargs)

        def translate_path(self, path):
            p = urlsplit(path).path
            if p.startswith("/_kit/"):
                # subfolders allowed (/_kit/motion/bars/...), never outside the kit
                rel = os.path.normpath(unquote(p[len("/_kit/"):])).lstrip("/")
                full = os.path.join(kit, rel)
                if rel.startswith("..") or not os.path.abspath(full).startswith(os.path.abspath(kit) + os.sep):
                    return os.path.join(kit, "__nope__")
                return full
            return super().translate_path(path)

        def send_json(self, obj, code=200):
            data = json.dumps(obj, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def local_origin(self):
            # only the deck's own page (localhost or an --allow-origin host) may write
            origin = self.headers.get("Origin")
            if origin and (urlsplit(origin).hostname or "").lower() not in allowed:
                self.send_error(403)
                return False
            return True

        def do_GET(self):
            if self.path == "/agent":
                self.send_json(agent.status())
                return
            if self.path in paths:
                data = b"{}"
                if os.path.exists(paths[self.path]):
                    with open(paths[self.path], "rb") as f:
                        data = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            super().do_GET()

        def do_POST(self):
            url = urlsplit(self.path)
            if not self.local_origin():
                return
            if url.path == "/notes/clear":
                self.clear_notes()
                return
            if url.path in ("/agent/plan", "/agent/apply"):
                ok, msg = agent.start(url.path.rsplit("/", 1)[1])
                self.send_json({"ok": ok, "message": msg, **agent.status()}, 200 if ok else 409)
                return
            if url.path not in paths:
                self.send_error(404)
                return
            target = paths[url.path]
            key = parse_qs(url.query).get("key", [None])[0]
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                notes = json.loads(body)
                assert isinstance(notes, dict)
            except Exception:
                self.send_error(400, "invalid JSON")
                return
            with lock:
                if key is not None:
                    merged = {}
                    if os.path.exists(target):
                        with open(target, encoding="utf-8") as f:
                            merged = json.load(f)
                    merged[key] = notes
                    notes = merged
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), suffix=".tmp")
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(notes, f, ensure_ascii=False, indent=2, sort_keys=True)
                os.replace(tmp, target)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok": true}')

        def clear_notes(self):
            # a copy is kept so a mis-tap is never a loss
            if not self.local_origin():
                return
            if agent.run:
                self.send_json({"ok": False, "message": "Claude is working on the notes; clear them when it finishes."}, 409)
                return
            with lock:
                agent.forget_slides()
                count = 0
                if os.path.exists(notes_path):
                    with open(notes_path, encoding="utf-8") as f:
                        count = len(json.load(f))
                    if count:
                        keep = os.path.join(os.path.dirname(notes_path), "notes-cleared")
                        os.makedirs(keep, exist_ok=True)
                        stem = os.path.splitext(os.path.basename(notes_path))[0]
                        stamp = datetime.datetime.now().strftime("%Y-%m-%d-%H%M%S")
                        shutil.copy2(notes_path, os.path.join(keep, f"{stem}-{stamp}.json"))
                with open(notes_path, "w", encoding="utf-8") as f:
                    f.write("{}")
            self.send_json({"ok": True, "cleared": count})

        def log_message(self, fmt, *args):
            pass

    print(f"Slideshow: http://localhost:{a.port}/")
    print(f"Notes file: {notes_path}")
    if allowed - {"localhost", "127.0.0.1"}:
        print(f"Also accepts notes from: {', '.join(sorted(allowed - {'localhost', '127.0.0.1'}))}")
    # Threaded so a long video download never blocks the notes or store requests.
    ThreadingHTTPServer(("127.0.0.1", a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
