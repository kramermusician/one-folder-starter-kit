# Knowledge

My shelf of finished, approved work. If it's in here, it's the real version.

- One folder per course (for example `knowledge/Guitar-101/`), with its schedule, lesson plans and handouts.
- My teaching schedule, and anything else I'd hand to someone as final.

Rules: only I move things in here. Claude saves new work to `owners-inbox/_New/` first; once I approve it, I (or Claude, when I say so) move it here.
