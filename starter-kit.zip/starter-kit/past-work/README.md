# Past Work

Work that missed my standard. Nothing here is deleted: each miss is how the system learns.

- Save the file here with the date in its name, like `2026-11-20-week-3-handout-v1.pdf`.
- Log the miss in `failure-journal.md`.
