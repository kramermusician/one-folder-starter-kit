# Failure Journal

Every miss gets an entry, newest at the top. The point is not blame: each entry turns a mistake into a rule, so it doesn't happen twice. Claude reads the last few entries at the start of every session.

## Format

```
## YYYY-MM-DD: Short name of the miss

What went wrong: one or two sentences.
The file: past-work/<the file>, if one was kept.
The rule that fixes it: one line.
Where the rule lives now: the SOP or teammate file it was written into.
```

---
