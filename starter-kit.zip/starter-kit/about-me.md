# About me

Replace everything on this page with your homework file: who you are, what you teach, what you want help with, your dream team, the tools you already use, the people who come up often, and the lines your system never crosses.

Writing in Spanish is fine. Claude reads both.

When it's in, open Claude (open-claude.command) and say:

"Read my about-me file and fill in CLAUDE.md: who I am, my system's name, my teaching, and my team. Ask me before you guess."
