#!/bin/bash
# Step 4: install Whisper, the speech-to-text model that runs on your own Mac.
# No Homebrew, no admin password. Everything goes in ~/.onefolder (outside Dropbox). Safe to run twice.
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
OF="$HOME/.onefolder"
VENV="$OF/venv"
PY="$VENV/bin/python"
mkdir -p "$OF"
start=$(date +%s)

echo ""
echo "Installing Whisper. About five minutes the first time. Leave this window open."
echo ""

# 1. uv: a small tool that installs Python for us
UV="$(command -v uv || true)"
if [ -z "$UV" ] && [ -x "$HOME/.local/bin/uv" ]; then UV="$HOME/.local/bin/uv"; fi
if [ -z "$UV" ]; then
  echo "1/4  Getting uv (Python installer) ..."
  curl -LsSf https://astral.sh/uv/install.sh | env UV_NO_MODIFY_PATH=1 sh >/dev/null 2>&1
  UV="$HOME/.local/bin/uv"
fi
[ -x "$UV" ] || { echo "CHECK: could not install uv. Show Kramer this window."; exit 1; }
echo "1/4  uv ready"

# 2. A private Python just for your system
if [ ! -x "$PY" ]; then
  echo "2/4  Making a private Python 3.12 ..."
  "$UV" venv -q -p 3.12 "$VENV" || { echo "CHECK: Python setup failed. Show Kramer this window."; exit 1; }
fi
echo "2/4  Python ready"

# 3. Whisper plus helpers (ffmpeg reads audio, reportlab makes PDFs)
if [ "$(uname -m)" = "arm64" ]; then
  PKG="mlx-whisper"
else
  PKG="faster-whisper"
  echo "     Intel Mac: using the smaller, slower Whisper. Memos still work, they just take longer."
fi
echo "3/4  Installing $PKG, ffmpeg, reportlab ..."
"$UV" pip install -q -p "$PY" "$PKG" imageio-ffmpeg reportlab pypdf || { echo "CHECK: install failed. Check your wifi and run this again."; exit 1; }
FF="$("$PY" -c 'import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())')"
ln -sf "$FF" "$VENV/bin/ffmpeg"
echo "3/4  Installed"

# 4. First run downloads the model (about 1.6 GB on Apple chips), then transcribes the sample
echo "4/4  Downloading the speech model and testing it on sample.m4a and sample-es.m4a ..."
echo ""
out="$("$PY" "$HERE/tools/transcribe.py" "$HERE/sample.m4a" 2>/dev/null)"
out_es="$("$PY" "$HERE/tools/transcribe.py" "$HERE/sample-es.m4a" 2>/dev/null)"
secs=$(( $(date +%s) - start ))
echo "     Whisper heard (English sample):"
echo "     $out"
echo "     Whisper heard (Spanish sample):"
echo "     $out_es"
echo ""
if [ -n "$out" ]; then
  echo "CHECK: Whisper works on this Mac (took ${secs}s). Nothing left your computer. Next, double-click 04-start-watcher.command"
else
  echo "CHECK: the test didn't produce text. Run this file again; if it fails twice, show Kramer."
fi
echo ""
