#!/bin/bash
# Opens Claude inside this folder, so everything it makes lands here.
cd "$(dirname "$0")" || exit 1
export PATH="$HOME/.local/bin:$PATH"
if ! command -v claude >/dev/null 2>&1; then
  echo "Claude Code isn't installed yet. Double-click 02-install-claude-code.command first."
  read -r -p "Press Return to close."
  exit 1
fi
echo "Opening Claude in $(basename "$(pwd)"). Type /exit when you're done."
echo ""
exec claude
