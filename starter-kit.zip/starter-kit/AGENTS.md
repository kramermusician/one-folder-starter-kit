Read CLAUDE.md in this folder and follow it as your instructions. It is the brain of this system.
